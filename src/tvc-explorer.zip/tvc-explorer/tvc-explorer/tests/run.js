const a=require('assert'),C=require('../js/core.js');
const T=Float64Array.from([0,0.01,0.03,0.04,1]);
a.strictEqual(C.nearest(T,-5),0);a.strictEqual(C.nearest(T,0.026),2);a.strictEqual(C.nearest(T,0.9),4);a.strictEqual(C.nearest(T,0.0149),1);
a.strictEqual(C.unit('angle_x'),'deg');a.strictEqual(C.unit('gx'),'deg/s');a.strictEqual(C.unit('az'),'g');a.strictEqual(C.unit('servo3'),'deg');a.strictEqual(C.unit('foo'),'');
a.strictEqual(C.unit('d_y'),'deg');a.strictEqual(C.unit('pid_z'),'deg');
console.log('core tests passed');
