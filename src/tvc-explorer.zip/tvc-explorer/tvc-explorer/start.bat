@echo off
cd /d "%~dp0"
set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY python --version >nul 2>&1 && set "PY=python"
if not defined PY goto nopy
echo Starting local server at http://127.0.0.1:8080  (close this window to stop)
start "" /min cmd /c timeout /t 2 ^>nul ^& start http://127.0.0.1:8080/index.html
%PY% -m http.server 8080 --bind 127.0.0.1
pause
goto :eof
:nopy
echo Working Python not found - opening index.html directly (fully offline, no server needed).
start "" "%~dp0index.html"
