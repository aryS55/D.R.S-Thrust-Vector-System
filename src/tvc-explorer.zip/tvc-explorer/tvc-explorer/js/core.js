(function(g){
const RULES=[[/^(t_us|dt_us|tick_us|late_max_us|sd_max_us|esc_us|ch_thr|ch_arm)$/,'µs'],[/^time_ms$|^ibus_age_ms$/,'ms'],[/^raw_/,'LSB'],[/^(ax|ay|az|cal_a.|acc_norm)$/,'g'],
[/^(gx|gy|gz|rate_z|cal_g.|ekf_bias_.|ekf_sig_b.)$/,'deg/s'],[/^(angle_|err_|pid_|servo|fus_roll|fus_pitch|fus_acc_err|ekf_sig_[xy]|est_diff|[pid]_[xyz]$)/,'deg']];
function unit(c){for(const [r,u] of RULES)if(r.test(c))return u;return ''}
// index of sample nearest to t in sorted array T
function nearest(T,t){let lo=0,hi=T.length-1;while(hi-lo>1){const m=(lo+hi)>>1;if(T[m]<=t)lo=m;else hi=m}return Math.abs(T[lo]-t)<=Math.abs(T[hi]-t)?lo:hi}
const API={unit,nearest};if(typeof module!=='undefined'&&module.exports)module.exports=API;else g.Core=API;
})(typeof window!=='undefined'?window:this);
