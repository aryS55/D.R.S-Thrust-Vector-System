(()=>{
const $=i=>document.getElementById(i),C=window.Core,PAL=['#4fc3f7','#ff8a65','#81c784','#ba68c8','#ffd54f','#f06292','#4db6ac','#a1887f','#90a4ae','#dce775'];
const S={panels:[],markers:[],trace:true,t:0,prev:0,hi:null,hp:null,tip:[0,0],playing:false,speed:1,xr:null,range:25};
let D=null,syncing=false,raf=0,uid=0,R=null,lastTs=0;
const dur=()=>D?D.T[D.n-1]:0,si=()=>C.nearest(D.T,S.t),esc=s=>String(s).replace(/[&<>"]/g,c=>'&#'+c.charCodeAt(0)+';');
const fmt=v=>Number.isFinite(v)?String(+v.toFixed(5)):'—',soon=()=>{if(!raf)raf=requestAnimationFrame(refresh)};
const PRE={'Attitude and Setpoints':[['Attitude and Setpoints',['angle_x','angle_y','angle_x_sp','angle_y_sp']]],'Gyroscope':[['Gyroscope',['gx','gy','gz','rate_z']]],
'Accelerometer':[['Accelerometer',['ax','ay','az']]],'Control Errors':[['Control Errors',['err_x','err_y']]],'PID Outputs':[['PID Outputs',['pid_x','pid_y','pid_z']]],
'Servo Commands':[['Servo Commands',['servo1','servo2','servo3','servo4']]]};
PRE['Flight Overview']=[PRE['Attitude and Setpoints'][0],PRE['Control Errors'][0],PRE['PID Outputs'][0],PRE['Servo Commands'][0],PRE['Gyroscope'][0]];
const pt=a=>['PID terms '+a.toUpperCase()+' (P / I / D + total)',['p_'+a,'i_'+a,'d_'+a,'pid_'+a]];
PRE['PID Terms X']=[pt('x')];PRE['PID Terms Y']=[pt('y')];PRE['PID Terms Z']=[pt('z')];PRE['PID Terms (all axes)']=[pt('x'),pt('y'),pt('z')];

// ---------- loading ----------
function load(f){$('fname').textContent='Loading '+f.name+'…';
 Papa.parse(f,{header:true,dynamicTyping:true,skipEmptyLines:'greedy',comments:'#',newline:'\n',transformHeader:h=>h.trim(),complete:r=>{try{
  const fl=(r.meta.fields||[]).filter(x=>x!==''&&x!=null);if(!fl.includes('time_ms'))throw Error('No "time_ms" column - not a TVC log?');
  const T=[],cols={};fl.forEach(c=>cols[c]=[]);let bad=0,last=-Infinity,t0=null;
  for(const row of r.data){const t=row.time_ms;if(typeof t!=='number'||!isFinite(t)||t<last){bad++;continue}
   if(t0===null)t0=t;last=t;T.push((t-t0)/1000);for(const c of fl){const v=row[c];cols[c].push(typeof v==='number'&&isFinite(v)?v:NaN)}}
  if(T.length<2)throw Error('Fewer than 2 valid rows.');
  clearAll();D={name:f.name,cols:fl,n:T.length,T:Float64Array.from(T),data:{}};fl.forEach(c=>D.data[c]=Float64Array.from(cols[c]));
  S.t=0;S.xr=null;S.markers=[];$('fname').textContent=f.name;$('dur').textContent=dur().toFixed(2)+' s · '+D.n+' rows'+(bad?' · '+bad+' bad rows skipped':'');
  $('cols').textContent='Columns: '+fl.join(', ');$('slider').max=dur();fields();preset('Flight Overview');mrk();soon();
 }catch(e){$('fname').textContent='Error: '+e.message}},error:e=>{$('fname').textContent='Error: '+e.message}})}
function clearAll(){S.panels.slice().forEach(rm);D=null;S.playing=false}

// ---------- panels ----------
function add(title,sigs,yr,h){const p={id:++uid,title,yr:yr||null,h:h||0,sigs:sigs.map((s,i)=>typeof s==='string'?{c:s,k:i,hide:false,y2:false}:s)};S.panels.push(p);mk(p);return p}
function rm(p){S.panels=S.panels.filter(q=>q!==p);try{Plotly.purge(p.el.querySelector('.plot'))}catch(e){}p.el.remove();targets()}
function mk(p){const e=p.el=document.createElement('section');e.className='panel';
 e.innerHTML='<div class="ph"><input class="ti"><span class="ro"></span><span class="bt"><button data-a="y" title="Y range">Y</button><button data-a="up">↑</button><button data-a="dn">↓</button><button data-a="dup" title="Duplicate">⧉</button><button data-a="col" title="Collapse">▾</button><button data-a="del">✕</button></span></div><div class="chips"></div><div class="wr"><div class="plot"></div><i class="ln hv"></i><i class="ln sl"></i><div class="mks"></div><div class="tip"></div></div><div class="rz" title="Drag to resize"></div>';
 $('graphs').appendChild(e);if(p.h)e.style.height=p.h+'px';const rz=e.querySelector('.rz');rz.onpointerdown=ev=>{rz.setPointerCapture(ev.pointerId);const y0=ev.clientY,h0=e.offsetHeight;rz.onpointermove=m=>{p.h=Math.max(90,Math.round(h0+m.clientY-y0));e.style.height=p.h+'px'};rz.onpointerup=()=>{rz.onpointermove=null}};const ti=e.querySelector('.ti');ti.value=p.title;ti.oninput=()=>{p.title=ti.value;targets()};
 e.querySelector('.bt').onclick=ev=>{const a=ev.target.dataset.a;if(!a)return;
  if(a==='y'){const v=prompt('Y range "min,max" (blank = auto)',p.yr?p.yr.join(','):'');if(v===null)return;const n=v.split(',').map(Number);p.yr=n.length===2&&n.every(isFinite)?n:null;draw(p)}
  if(a==='col')e.classList.toggle('collapsed');if(a==='del')rm(p);
  if(a==='dup'){const q=add(p.title+' (copy)',p.sigs.map(s=>({...s})),p.yr&&[...p.yr],p.h);draw(q);targets()}
  if(a==='up'||a==='dn'){const i=S.panels.indexOf(p),j=i+(a==='up'?-1:1);if(j<0||j>=S.panels.length)return;[S.panels[i],S.panels[j]]=[S.panels[j],S.panels[i]];const o=S.panels[i];a==='up'?$('graphs').insertBefore(e,o.el):$('graphs').insertBefore(o.el,e);S.panels.forEach(overlay);targets()}};
 e.querySelector('.chips').onclick=ev=>{const a=ev.target.dataset.a,c=ev.target.closest('.chip');if(!a||!c)return;const s=p.sigs[+c.dataset.i];
  if(a==='eye')s.hide=!s.hide;if(a==='ax')s.y2=!s.y2;if(a==='x')p.sigs.splice(+c.dataset.i,1);draw(p)};
 new ResizeObserver(()=>{const el=e.querySelector('.plot');if(el._fullLayout)Plotly.Plots.resize(el).then(()=>overlay(p))}).observe(e.querySelector('.plot'));targets()}
function draw(p){if(!D)return;const el=p.el.querySelector('.plot'),ok=p.sigs.filter(s=>D.data[s.c]);
 p.el.querySelector('.chips').innerHTML=p.sigs.map((s,i)=>'<span class="chip'+(s.hide?' off':'')+(D.data[s.c]?'':' miss')+'" data-i="'+i+'" style="--c:'+PAL[s.k%10]+'"><b>'+s.c+'</b><u data-a="eye">◉</u><u data-a="ax" title="Right Y axis">⇄</u><u data-a="x">×</u></span>').join('');
 const un=y2=>[...new Set(ok.filter(s=>!!s.y2===y2).map(s=>C.unit(s.c)).filter(Boolean))].join(', ');
 const tr=ok.map(s=>({x:D.T,y:D.data[s.c],name:s.c+(C.unit(s.c)?' ['+C.unit(s.c)+']':''),type:'scattergl',mode:'lines',line:{color:PAL[s.k%10],width:1.3},visible:!s.hide,yaxis:s.y2?'y2':'y',hoverinfo:'skip',connectgaps:false}));
 const ax={gridcolor:'#1f2937',zerolinecolor:'#334155'},two=ok.some(s=>s.y2);
 const L={paper_bgcolor:'#0f1319',plot_bgcolor:'#0f1319',font:{color:'#9aa7b5',size:11},margin:{l:58,r:two?58:14,t:22,b:34},dragmode:'pan',legend:{orientation:'h',x:0,y:1.14},
  xaxis:{...ax,title:'time (s)',range:S.xr||[0,dur()],autorange:!S.xr},yaxis:{...ax,title:un(false),range:p.yr||undefined,autorange:!p.yr},yaxis2:{...ax,overlaying:'y',side:'right',title:un(true),showgrid:false}};
 Plotly.react(el,tr,L,{scrollZoom:true,displaylogo:false,responsive:false,modeBarButtonsToRemove:['toImage','select2d','lasso2d']}).then(()=>{if(!p.bound){p.bound=true;bind(p,el)}overlay(p)})}
function at(p,el,ev){const xa=el._fullLayout.xaxis,px=ev.clientX-el.getBoundingClientRect().left-xa._offset;return px<0||px>xa._length?null:C.nearest(D.T,xa.p2l(px))}
function bind(p,el){
 el.on('plotly_relayout',ev=>{if(syncing)return;
  if('yaxis.range[0]' in ev)p.yr=[ev['yaxis.range[0]'],ev['yaxis.range[1]']];if(ev['yaxis.autorange'])p.yr=null;
  if('xaxis.range[0]' in ev)S.xr=[ev['xaxis.range[0]'],ev['xaxis.range[1]']];else if(ev['xaxis.autorange'])S.xr=null;else return overlay(p);syncX(p)});
 el.addEventListener('mousemove',ev=>{if(!S.trace||!D||!el._fullLayout.xaxis)return;S.hi=at(p,el,ev);S.hp=p;const r=el.getBoundingClientRect();S.tip=[ev.clientX-r.left,ev.clientY-r.top];soon()});
 el.addEventListener('mouseleave',()=>{S.hi=null;soon()});let dx=0;el.addEventListener('mousedown',ev=>dx=ev.clientX);
 el.addEventListener('click',ev=>{if(Math.abs(ev.clientX-dx)>4)return;const i=at(p,el,ev);if(i!==null){S.prev=S.t;setT(D.T[i])}})}
function syncX(src){syncing=true;Promise.all(S.panels.filter(q=>q!==src).map(q=>Plotly.relayout(q.el.querySelector('.plot'),S.xr?{'xaxis.range':S.xr}:{'xaxis.autorange':true}))).then(()=>{syncing=false;S.panels.forEach(overlay);vInputs()})}
function geom(p){const fl=p.el.querySelector('.plot')._fullLayout;return fl&&fl.xaxis&&fl.xaxis._length?{xa:fl.xaxis,ya:fl.yaxis}:null}
function overlay(p){const g=geom(p);if(!g)return;p.el.querySelector('.mks').innerHTML=S.markers.map(k=>{const x=g.xa._offset+g.xa.l2p(k.t);return x<g.xa._offset||x>g.xa._offset+g.xa._length?'':'<i class="ln mk" title="'+esc(k.label)+'" style="left:'+x+'px;top:'+g.ya._offset+'px;height:'+g.ya._length+'px"></i>'}).join('');cur(p)}
function cur(p){const g=geom(p);if(!g||!D)return;const put=(el,t)=>{const x=g.xa._offset+g.xa.l2p(t),ok=t!==null&&x>=g.xa._offset&&x<=g.xa._offset+g.xa._length;el.style.display=ok?'block':'none';if(ok){el.style.left=x+'px';el.style.top=g.ya._offset+'px';el.style.height=g.ya._length+'px'}};
 put(p.el.querySelector('.hv'),S.hi===null?null:D.T[S.hi]);put(p.el.querySelector('.sl'),D.T[si()])}

// ---------- refresh ----------
function setT(t){S.t=Math.min(Math.max(t,0),dur());soon()}
function refresh(){raf=0;if(!D)return;const s=si();$('slider').value=S.t;if(document.activeElement!==$('tin'))$('tin').value=S.t.toFixed(3);$('play').textContent=S.playing?'❚❚ Pause':'▶ Play';
 S.panels.forEach(p=>{cur(p);const i=S.hi!==null?S.hi:s,v=p.sigs.filter(x=>!x.hide&&D.data[x.c]);
  p.el.querySelector('.ro').innerHTML='<em>t='+D.T[i].toFixed(4)+' s'+(S.hi!==null?' (trace)':' (selected)')+'</em>'+v.map(x=>'<span style="color:'+PAL[x.k%10]+'">'+x.c+' '+fmt(D.data[x.c][i])+'</span>').join('');
  const tip=p.el.querySelector('.tip');if(S.hi!==null&&S.hp===p){tip.style.display='block';tip.innerHTML='t = '+D.T[i].toFixed(4)+' s  (sample '+i+')\n'+v.map(x=>'<span style="color:'+PAL[x.k%10]+'">'+x.c+': '+fmt(D.data[x.c][i])+'</span>').join('\n');
   const w=p.el.querySelector('.wr');tip.style.left=Math.min(S.tip[0]+14,w.clientWidth-190)+'px';tip.style.top=Math.min(S.tip[1]+10,w.clientHeight-30-v.length*14)+'px'}else tip.style.display='none'});
 rocket(s);servos(s);motor(s)}
function tick(ts){if(!S.playing)return;S.t+=(ts-lastTs)/1000*S.speed;lastTs=ts;if(S.t>=dur()){S.t=dur();S.playing=false}soon();if(S.playing)requestAnimationFrame(tick)}
function play(){if(!D)return;if(S.playing){S.playing=false;return soon()}if(S.t>=dur())S.t=0;S.playing=true;lastTs=performance.now();requestAnimationFrame(tick)}

// ---------- 3D rocket (firmware frame: +Z up, +X FIN2, +Y FIN1; R = Ry(angle_y)*Rx(angle_x)) ----------
function initRocket(){const h=$('rk'),r=new THREE.WebGLRenderer({antialias:true,alpha:true});h.appendChild(r.domElement);
 const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(40,1,.1,50);cam.position.set(3.2,2.2,3.2);
 const oc=new THREE.OrbitControls(cam,r.domElement);sc.add(new THREE.AmbientLight(0xffffff,.7));const dl=new THREE.DirectionalLight(0xffffff,.8);dl.position.set(3,5,2);sc.add(dl);
 const fw=new THREE.Group();fw.rotation.x=-Math.PI/2;sc.add(fw);fw.add(new THREE.AxesHelper(1.6));
 const rk=new THREE.Group();rk.rotation.order='YXZ';fw.add(rk);const M=c=>new THREE.MeshStandardMaterial({color:c});
 rk.add(new THREE.Mesh(new THREE.CylinderGeometry(.25,.25,2,24).rotateX(Math.PI/2),M(0xcfd8dc)));
 const nose=new THREE.Mesh(new THREE.ConeGeometry(.25,.7,24).rotateX(Math.PI/2),M(0xff7043));nose.position.z=1.35;rk.add(nose);
 const fins=[[0,1,0xef5350],[1,0,0x66bb6a],[0,-1,0x42a5f5],[-1,0,0xffca28]].map(([x,y,c])=>{const g=new THREE.Group();g.position.set(x*.5,y*.5,-.8);
  g.add(new THREE.Mesh(new THREE.BoxGeometry(...(x?[.5,.03,.5]:[.03,.5,.5])),M(c)));rk.add(g);return{g,ax:x?'x':'y',sg:x+y>0?1:-1}});
 const draw=()=>r.render(sc,cam);oc.addEventListener('change',draw);
 new ResizeObserver(()=>{const w=h.clientWidth,hh=h.clientHeight;if(!w||!hh)return;r.setSize(w,hh,false);cam.aspect=w/hh;cam.updateProjectionMatrix();draw()}).observe(h);R={rk,fins,draw}}
function rocket(i){if(!R)return;const a=D.data.angle_x?.[i],b=D.data.angle_y?.[i],d=Math.PI/180;
 R.rk.rotation.x=Number.isFinite(a)?a*d:0;R.rk.rotation.y=Number.isFinite(b)?b*d:0;
 R.fins.forEach((f,k)=>{const v=D.data['servo'+(k+1)]?.[i];f.g.rotation[f.ax]=Number.isFinite(v)?f.sg*v*d:0});
 $('att').textContent='angle_x '+fmt(a)+'° · angle_y '+fmt(b)+'°  (commanded fin deflection shown, not measured)';R.draw()}
const FN=['FIN1 (+Y)','FIN2 (+X)','FIN3 (-Y)','FIN4 (-X)'];
$('sv').innerHTML=FN.map((n,k)=>'<div class="sv"><label>S'+(k+1)+' · '+n+'</label><div class="bar"><i></i></div><div class="vane"></div><output></output></div>').join('');
function servos(i){document.querySelectorAll('.sv').forEach((e,k)=>{const v=D.data['servo'+(k+1)]?.[i],R_=S.range||25,f=e.querySelector('i');
 if(!Number.isFinite(v)){f.style.width='0';e.querySelector('output').textContent='—';return}
 const w=Math.min(Math.abs(v)/R_,1)*50;f.style.width=w+'%';f.style.left=(v>=0?50:50-w)+'%';e.querySelector('.vane').style.transform='rotate('+(-v)+'deg)';e.querySelector('output').textContent=v.toFixed(2)+'°'})}
function motor(i){const m=D.cols.filter(c=>/^(esc_us|ch_thr|ch_arm|armed|thr|motor|throttle)/i.test(c));
 $('motor').innerHTML=m.length?m.map(c=>c+': <b>'+fmt(D.data[c][i])+'</b> '+C.unit(c)).join('<br>'):'<small>No throttle/motor columns in this recording.</small>'}

// ---------- sidebar / presets / markers / workspace ----------
function fields(){const q=$('q').value.toLowerCase();$('fields').innerHTML=D?D.cols.filter(c=>c.toLowerCase().includes(q)).map(c=>'<li data-c="'+c+'">'+c+' <small>'+C.unit(c)+'</small></li>').join(''):''}
function targets(){const v=$('target').value;$('target').innerHTML=S.panels.map(p=>'<option value="'+p.id+'">'+esc(p.title)+'</option>').join('');if(v)$('target').value=v}
function preset(n){if(!D)return;let k=0;PRE[n].forEach(([t,c])=>{const s=c.filter(x=>D.data[x]);if(s.length){draw(add(t,s));k++}});if(!k){if(S.panels.length)alert('That preset\'s columns are not in the loaded file.');else draw(add('Graph',[D.cols.find(c=>c!=='time_ms')]))}$('graphs').lastElementChild?.scrollIntoView({block:'nearest'});soon()}
function mrk(){const d=D?dur():1;$('mstrip').innerHTML=S.markers.map((k,i)=>'<i data-i="'+i+'" title="'+esc(k.label)+'" style="left:'+k.t/d*100+'%"></i>').join('');
 $('mlist').innerHTML=S.markers.map((k,i)=>'<span data-i="'+i+'"><a data-a="go">'+k.t.toFixed(3)+'s '+esc(k.label)+'</a> <u data-a="ed">✎</u> <u data-a="rm">✕</u></span>').join('');S.panels.forEach(overlay)}
function vInputs(){$('vf').value=(S.xr?S.xr[0]:0).toFixed(2);$('vt').value=(S.xr?S.xr[1]:D?dur():0).toFixed(2)}
function setView(r){S.xr=r;syncing=true;Promise.all(S.panels.map(q=>Plotly.relayout(q.el.querySelector('.plot'),r?{'xaxis.range':r}:{'xaxis.autorange':true}))).then(()=>{syncing=false;S.panels.forEach(overlay);vInputs()})}
function saveWs(){const w={v:1,trace:S.trace,xr:S.xr,range:S.range,markers:S.markers,panels:S.panels.map(p=>({title:p.title,yr:p.yr,sigs:p.sigs,h:p.h}))};
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(w,null,1)],{type:'application/json'}));a.download='tvc-workspace.json';a.click();URL.revokeObjectURL(a.href)}
function loadWs(f){if(!D){alert('Open a flight first, then load the workspace.');return}f.text().then(t=>{const w=JSON.parse(t);S.panels.slice().forEach(rm);S.xr=w.xr||null;S.markers=w.markers||[];S.trace=w.trace!==false;S.range=w.range||25;
 $('trace').checked=S.trace;$('rng').value=S.range;(w.panels||[]).forEach(q=>draw(add(q.title,q.sigs,q.yr,q.h)));mrk();vInputs();soon()}).catch(e=>alert('Bad workspace file: '+e.message))}

// ---------- wiring ----------
$('open').onclick=()=>$('file').click();$('file').onchange=e=>{if(e.target.files[0])load(e.target.files[0]);e.target.value=''};
$('clear').onclick=()=>{clearAll();S.markers=[];$('fname').textContent='No file loaded';$('dur').textContent='';$('cols').textContent='';fields();mrk()};
$('play').onclick=play;$('stop').onclick=()=>{S.playing=false;setT(0)};$('restart').onclick=()=>{if(!D)return;S.t=0;S.playing=false;play()};
$('first').onclick=()=>setT(0);$('last').onclick=()=>setT(dur());
$('back').onclick=()=>D&&setT(D.T[Math.max(si()-1,0)]);$('fwd').onclick=()=>D&&setT(D.T[Math.min(si()+1,D.n-1)]);
$('speed').onchange=e=>S.speed=+e.target.value;$('trace').onchange=e=>{S.trace=e.target.checked;if(!S.trace)S.hi=null;soon()};
$('slider').oninput=e=>setT(+e.target.value);$('tin').onchange=e=>setT(+e.target.value);$('rng').onchange=e=>{S.range=+e.target.value||25;soon()};
$('addM').onclick=()=>{if(!D)return;const l=prompt('Marker label','Marker');if(l===null)return;S.markers.push({t:D.T[si()],label:l});S.markers.sort((a,b)=>a.t-b.t);mrk()};
$('ret').onclick=()=>setT(S.prev);
const mh=e=>{const i=e.target.closest('[data-i]')?.dataset.i,a=e.target.dataset.a;if(i===undefined)return;const k=S.markers[+i];
 if(a==='rm'){S.markers.splice(+i,1);mrk()}else if(a==='ed'){const l=prompt('Label',k.label);if(l!==null){k.label=l;mrk()}}else setT(k.t)};
$('mlist').onclick=mh;$('mstrip').onclick=mh;
$('vf').onchange=$('vt').onchange=()=>{if(D){const a=+$('vf').value,b=+$('vt').value;if(b>a)setView([a,b])}};$('vr').onclick=()=>setView(null);
$('q').oninput=fields;$('fields').onclick=e=>{const c=e.target.closest('li')?.dataset.c;if(!c||!D)return;let p=S.panels.find(p=>p.id==$('target').value);if(!p)p=add('Graph',[]);
 if(!p.sigs.some(s=>s.c===c)){p.sigs.push({c,k:p.sigs.length,hide:false,y2:false});draw(p)}};
$('newG').onclick=()=>{if(D){draw(add('Graph '+(S.panels.length+1),[]));$('target').value=S.panels[S.panels.length-1].id}};$('clrG').onclick=()=>S.panels.slice().forEach(rm);
$('pre').innerHTML=Object.keys(PRE).map(n=>'<button>'+n+'</button>').join('');$('pre').onclick=e=>{if(e.target.tagName==='BUTTON')preset(e.target.textContent)};
$('saveWs').onclick=saveWs;$('loadWs').onclick=()=>$('wsFile').click();$('wsFile').onchange=e=>{if(e.target.files[0])loadWs(e.target.files[0]);e.target.value=''};
$('tSide').onclick=()=>$('side').classList.toggle('hid');$('tRight').onclick=()=>$('right').classList.toggle('hid');
addEventListener('keydown',e=>{if(e.target.tagName==='INPUT'||e.target.tagName==='SELECT')return;if(e.code==='Space'){e.preventDefault();play()}if(e.code==='ArrowLeft')$('back').click();if(e.code==='ArrowRight')$('fwd').click()});
addEventListener('resize',()=>S.panels.forEach(p=>{const el=p.el.querySelector('.plot');if(el._fullLayout)Plotly.Plots.resize(el).then(()=>overlay(p))}));
initRocket();
})();
