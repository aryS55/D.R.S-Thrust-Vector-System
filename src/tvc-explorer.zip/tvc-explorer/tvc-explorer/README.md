# TVC Flight Explorer
Offline, local-only viewer for the SD logs from tvc_rocket2.ino. No analysis, no export.
**Run:** double-click `start.bat` (starts a local server if Python works, otherwise opens index.html directly; you can also just double-click index.html). Chrome/Edge.
**Load data:** copy `LOGnnnn.CSV` from the microSD card, click *Open Flight*.
**Graphs:** click a field in the sidebar to add it to the chosen graph; chips toggle hide (◉), right axis (⇄), remove (×). Presets add a new graph at the bottom (use *Remove all graphs* to start over); drag the bar under a graph to change its height (axis ranges are unchanged). PID Terms presets graph p_/i_/d_ plus the total per axis (needs a log from the updated firmware). Drag = pan, wheel = zoom (X zoom is shared), Y button = set Y range, panels resize by dragging the bottom edge.
**Tracing:** move the mouse over any graph: white cursor snaps to real samples on every graph, values show in each panel header and a tooltip. Click pins the playback position (blue dashed); ↩ Return goes back to the previous one.
**Playback:** buttons / slider / time box / speed menu; Space = play/pause.
**Workspace:** Save/Load Workspace writes/reads a small JSON file (graphs, signals, ranges, markers). Nothing leaves your machine.
**Tests:** `node tests/run.js`.
